// ============================================================
//  SISTEM ABSENSI QR - CFD SUDIRMAN 2
//  Code.gs — menerima data dari halaman scanner eksternal
// ============================================================

const SPREADSHEET_ID = '1qLS3Wtb7QMnLYX6gcd1sdZ2YMNitB2oELySUF4fNnj4';
const SHEET_NAME_OVERRIDE = '';
const FOLDER_NAME = 'Foto Absensi CFD Sudirman 2';

function getSheetName() {
  if (SHEET_NAME_OVERRIDE !== '') return SHEET_NAME_OVERRIDE;
  const bulan = ['JANUARI','FEBRUARI','MARET','APRIL','MEI','JUNI',
                 'JULI','AGUSTUS','SEPTEMBER','OKTOBER','NOVEMBER','DESEMBER'];
  const now = new Date();
  return 'ABSENSI ' + now.getDate() + ' ' + bulan[now.getMonth()];
}

function getFolder() {
  const folders = DriveApp.getFoldersByName(FOLDER_NAME);
  if (folders.hasNext()) return folders.next();
  return DriveApp.createFolder(FOLDER_NAME);
}

// doGet tetap ada untuk test deployment
function doGet(e) {
  return HtmlService.createHtmlOutput('<h2>✅ Apps Script aktif</h2><p>Gunakan halaman scanner eksternal untuk absensi.</p>');
}

// ── doPost: menerima data JSON dari halaman eksternal ──────
function doPost(e) {
  try {
    const data      = JSON.parse(e.postData.contents);
    const action    = data.action; // 'absensi' atau 'foto'

    if (action === 'absensi') {
      const result = prosesAbsensi(data);
      return ContentService
        .createTextOutput(JSON.stringify(result))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'foto') {
      const result = prosesFoto(data);
      return ContentService
        .createTextOutput(JSON.stringify(result))
        .setMimeType(ContentService.MimeType.JSON);
    }

    return ContentService
      .createTextOutput(JSON.stringify({ sukses: false, pesan: 'Action tidak dikenal' }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch(err) {
    return ContentService
      .createTextOutput(JSON.stringify({ sukses: false, pesan: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function prosesAbsensi(data) {
  const parts     = (data.qrText || '').split('\t');
  const nama      = (parts[0] || '').trim();
  const namaUsaha = (parts[1] || '').trim();
  const noIdCard  = (parts[2] || '').trim();
  const noHp      = (parts[3] || '').trim();
  const lokasi    = (parts[4] || '').trim();

  const now     = new Date();
  const tz      = Session.getScriptTimeZone();
  const tanggal = Utilities.formatDate(now, tz, 'dd/MM/yyyy');
  const jamScan = Utilities.formatDate(now, tz, 'HH:mm:ss');

  const ss        = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheetName = getSheetName();
  let sheet       = ss.getSheetByName(sheetName);

  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
    const header = ['NO','Tanggal','Kehadiran','Nama Owner/Crew',
                    'Nama Usaha','No Id Card','No Hp/Wa','Lokasi','Foto Kehadiran'];
    sheet.appendRow(header);
    sheet.getRange(1,1,1,header.length)
         .setFontWeight('bold')
         .setBackground('#1a73e8')
         .setFontColor('#ffffff');
  }

  const lastRow = sheet.getLastRow();
  if (lastRow > 1 && noIdCard !== '') {
    const idList = sheet.getRange(2, 6, lastRow - 1, 1).getValues().flat();
    if (idList.includes(noIdCard)) {
      return { sukses: false, pesan: '⚠️ ' + nama + ' sudah tercatat hari ini!' };
    }
  }

  const no     = lastRow;
  const newRow = lastRow + 1;
  sheet.appendRow([no, tanggal, jamScan, nama, namaUsaha, noIdCard, noHp, lokasi, '']);

  return {
    sukses   : true,
    pesan    : '✅ ' + nama + ' (' + namaUsaha + ') absen pukul ' + jamScan,
    rowIndex : newRow,
    sheetName: sheetName
  };
}

function prosesFoto(data) {
  const pure     = (data.base64 || '').replace(/^data:image\/\w+;base64,/, '');
  const blob     = Utilities.newBlob(Utilities.base64Decode(pure), 'image/jpeg', data.fileName || 'foto.jpg');
  const folder   = getFolder();
  const file     = folder.createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);

  const fileUrl = 'https://drive.google.com/file/d/' + file.getId() + '/view';

  const ss    = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheet = ss.getSheetByName(data.sheetName);
  if (sheet) sheet.getRange(data.rowIndex, 9).setValue(fileUrl);

  return { sukses: true, pesan: '📸 Foto berhasil disimpan!' };
}
